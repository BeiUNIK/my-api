"""
Celery Background Tasks
Handles scheduled and background processing
"""
from celery import Celery
from celery.schedules import crontab
from loguru import logger
import asyncio

from config.settings import settings

# Initialize Celery
celery_app = Celery(
    "passive_income_automation",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=["tasks"]
)

# Celery configuration
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=3600,  # 1 hour
    worker_prefetch_multiplier=1,
    # Beat schedule
    beat_schedule={
        "daily-content-pipeline": {
            "task": "tasks.run_content_pipeline",
            "schedule": crontab(hour=settings.CONTENT_SCHEDULE_HOUR, minute=0),
        },
        "onboarding-nudges": {
            "task": "tasks.send_onboarding_nudges",
            "schedule": crontab(hour=14, minute=0),  # 2 PM UTC
        },
        "daily-revenue-report": {
            "task": "tasks.send_daily_report",
            "schedule": crontab(hour=23, minute=55),  # End of day
        },
        "weekly-analytics": {
            "task": "tasks.send_weekly_analytics",
            "schedule": crontab(day_of_week=0, hour=9, minute=0),  # Sunday 9 AM
        },
    }
)


def run_async(coro):
    """Helper to run async functions in sync context"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(coro)


@celery_app.task(bind=True, max_retries=3)
def run_content_pipeline(self):
    """Run daily content generation pipeline"""
    logger.info("Starting content pipeline task")
    
    try:
        from modules.content_generator import content_pipeline
        run_async(content_pipeline.run_daily_pipeline())
        logger.info("Content pipeline completed")
        return {"status": "success", "message": "Content pipeline completed"}
    except Exception as exc:
        logger.error(f"Content pipeline failed: {exc}")
        self.retry(exc=exc, countdown=300)


@celery_app.task(bind=True, max_retries=3)
def send_onboarding_nudges(self):
    """Send nudges to stalled onboarding customers"""
    logger.info("Starting onboarding nudges task")
    
    try:
        from modules.onboarding import onboarding_manager
        run_async(onboarding_manager.send_progress_nudges())
        logger.info("Onboarding nudges sent")
        return {"status": "success", "message": "Onboarding nudges sent"}
    except Exception as exc:
        logger.error(f"Onboarding nudges failed: {exc}")
        self.retry(exc=exc, countdown=300)


@celery_app.task(bind=True, max_retries=3)
def send_daily_report(self):
    """Send daily revenue report"""
    logger.info("Generating daily report")
    
    try:
        from modules.payment_processor import payment_processor
        from utils.alerts import alert_manager
        
        stats = run_async(payment_processor.get_revenue_stats())
        
        run_async(alert_manager.daily_summary({
            "revenue": stats.get('month_revenue', 0),
            "new_customers": stats.get('month_payments', 0),
            "total_revenue": stats.get('total_revenue', 0)
        }))
        
        logger.info("Daily report sent")
        return {"status": "success", "stats": stats}
    except Exception as exc:
        logger.error(f"Daily report failed: {exc}")
        self.retry(exc=exc, countdown=300)


@celery_app.task(bind=True, max_retries=3)
def send_weekly_analytics(self):
    """Send weekly analytics report"""
    logger.info("Generating weekly analytics")
    
    try:
        from modules.lead_capture import lead_capture_manager
        from modules.payment_processor import payment_processor
        from modules.content_generator import content_generator
        from utils.alerts import alert_manager
        
        lead_stats = run_async(lead_capture_manager.get_lead_stats())
        payment_stats = run_async(payment_processor.get_revenue_stats())
        content_stats = run_async(content_generator.get_content_stats())
        
        report = {
            "leads": lead_stats,
            "revenue": payment_stats,
            "content": content_stats,
            "period": "weekly"
        }
        
        run_async(alert_manager.send_alert(
            title="Weekly Analytics Report",
            message=f"Weekly summary: ${payment_stats.get('month_revenue', 0)} revenue, {lead_stats.get('total_leads', 0)} leads",
            severity="info",
            details=report
        ))
        
        logger.info("Weekly analytics sent")
        return {"status": "success", "report": report}
    except Exception as exc:
        logger.error(f"Weekly analytics failed: {exc}")
        self.retry(exc=exc, countdown=300)


@celery_app.task(bind=True, max_retries=5)
def send_scheduled_email(self, email_id: str):
    """Send a scheduled email"""
    logger.info(f"Sending scheduled email: {email_id}")
    
    try:
        from database.supabase_client import get_supabase
        from modules.lead_capture import EmailSender
        
        supabase = get_supabase()
        email_sends = run_async(supabase.select("email_sends", {"id": email_id}))
        
        if not email_sends:
            logger.warning(f"Email not found: {email_id}")
            return {"status": "error", "message": "Email not found"}
        
        email = email_sends[0]
        
        # Send the email
        email_sender = EmailSender()
        # Implementation depends on email content storage
        
        logger.info(f"Scheduled email sent: {email_id}")
        return {"status": "success", "email_id": email_id}
    except Exception as exc:
        logger.error(f"Scheduled email failed: {exc}")
        self.retry(exc=exc, countdown=600)


@celery_app.task(bind=True, max_retries=3)
def generate_scheduled_content(self, content_id: str):
    """Generate content for a scheduled item"""
    logger.info(f"Generating scheduled content: {content_id}")
    
    try:
        from database.supabase_client import get_supabase
        from modules.content_generator import content_generator, ContentRequest
        
        supabase = get_supabase()
        contents = run_async(supabase.select("content", {"id": content_id}))
        
        if not contents:
            logger.warning(f"Content not found: {content_id}")
            return {"status": "error", "message": "Content not found"}
        
        content = contents[0]
        topic = content.get('metadata', {}).get('topic', content['title'])
        content_type = content.get('type', 'blog')
        
        request = ContentRequest(
            topic=topic,
            content_type=content_type
        )
        
        generated = run_async(content_generator.generate_content(request))
        
        # Update the scheduled item
        run_async(supabase.update(
            "content",
            content_id,
            {
                "title": generated.title,
                "slug": generated.slug,
                "content": generated.content,
                "excerpt": generated.excerpt,
                "status": "draft",
                "generated_at": "now()"
            }
        ))
        
        logger.info(f"Scheduled content generated: {content_id}")
        return {"status": "success", "content_id": content_id}
    except Exception as exc:
        logger.error(f"Scheduled content generation failed: {exc}")
        self.retry(exc=exc, countdown=300)


@celery_app.task
def process_webhook_event(event_id: str):
    """Process a stored webhook event"""
    logger.info(f"Processing webhook event: {event_id}")
    
    try:
        from database.supabase_client import get_supabase
        
        supabase = get_supabase()
        events = run_async(supabase.select("webhook_events", {"id": event_id}))
        
        if not events:
            return {"status": "error", "message": "Event not found"}
        
        event = events[0]
        
        # Process based on source
        if event['source'] == 'stripe':
            from modules.payment_processor import payment_processor
            # Re-process the event
            # This would need the original request context
            pass
        
        return {"status": "success", "event_id": event_id}
    except Exception as exc:
        logger.error(f"Webhook processing failed: {exc}")
        return {"status": "error", "message": str(exc)}


# Health check task
@celery_app.task
def health_check():
    """Celery health check"""
    return {"status": "healthy", "service": "celery"}
