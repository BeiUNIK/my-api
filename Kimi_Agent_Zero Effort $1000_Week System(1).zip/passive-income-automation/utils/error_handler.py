"""
Error Handling & Retry Logic
Production-ready error handling with exponential backoff
"""
import functools
import traceback
from typing import Callable, Any, Optional, TypeVar
from tenacity import (
    retry as tenacity_retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log,
    RetryError
)
from loguru import logger
import asyncio
import httpx

from utils.alerts import alert_manager


T = TypeVar('T')


class AutomationError(Exception):
    """Base exception for automation errors"""
    def __init__(self, message: str, error_code: str = None, details: dict = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "AUTOMATION_ERROR"
        self.details = details or {}


class PaymentError(AutomationError):
    """Payment processing errors"""
    pass


class EmailError(AutomationError):
    """Email sending errors"""
    pass


class ContentError(AutomationError):
    """Content generation errors"""
    pass


class DatabaseError(AutomationError):
    """Database operation errors"""
    pass


def with_retry(
    max_attempts: int = 3,
    min_wait: int = 2,
    max_wait: int = 30,
    exceptions: tuple = (Exception,)
):
    """
    Decorator for retry logic with exponential backoff
    
    Usage:
        @with_retry(max_attempts=3)
        async def my_function():
            pass
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs) -> T:
            for attempt in range(1, max_attempts + 1):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts:
                        logger.error(
                            f"Max retries ({max_attempts}) exceeded for {func.__name__}: {e}"
                        )
                        raise
                    
                    wait_time = min(min_wait * (2 ** (attempt - 1)), max_wait)
                    logger.warning(
                        f"Attempt {attempt}/{max_attempts} failed for {func.__name__}: {e}. "
                        f"Retrying in {wait_time}s..."
                    )
                    await asyncio.sleep(wait_time)
            
            raise RetryError(f"All {max_attempts} attempts failed")
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs) -> T:
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts:
                        logger.error(
                            f"Max retries ({max_attempts}) exceeded for {func.__name__}: {e}"
                        )
                        raise
                    
                    wait_time = min(min_wait * (2 ** (attempt - 1)), max_wait)
                    logger.warning(
                        f"Attempt {attempt}/{max_attempts} failed for {func.__name__}: {e}. "
                        f"Retrying in {wait_time}s..."
                    )
                    import time
                    time.sleep(wait_time)
            
            raise RetryError(f"All {max_attempts} attempts failed")
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    return decorator


def fallback(fallback_value: Any = None, alert_on_error: bool = True):
    """
    Decorator that returns a fallback value on error instead of raising
    
    Usage:
        @fallback(fallback_value=[])
        async def get_data():
            # Might fail
            return await fetch_data()
    """
    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Function {func.__name__} failed, using fallback: {e}")
                if alert_on_error:
                    await alert_manager.send_alert(
                        title=f"Fallback triggered: {func.__name__}",
                        message=str(e),
                        severity="warning"
                    )
                return fallback_value
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Function {func.__name__} failed, using fallback: {e}")
                if alert_on_error:
                    asyncio.create_task(alert_manager.send_alert(
                        title=f"Fallback triggered: {func.__name__}",
                        message=str(e),
                        severity="warning"
                    ))
                return fallback_value
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    return decorator


class CircuitBreaker:
    """
    Circuit breaker pattern to prevent cascading failures
    
    States:
        - CLOSED: Normal operation
        - OPEN: Failing fast, rejecting requests
        - HALF_OPEN: Testing if service recovered
    """
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type = Exception
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    def can_execute(self) -> bool:
        """Check if execution is allowed"""
        if self.state == "CLOSED":
            return True
        
        if self.state == "OPEN":
            import time
            if time.time() - self.last_failure_time >= self.recovery_timeout:
                self.state = "HALF_OPEN"
                logger.info("Circuit breaker entering HALF_OPEN state")
                return True
            return False
        
        return True  # HALF_OPEN
    
    def record_success(self):
        """Record successful execution"""
        self.failure_count = 0
        self.state = "CLOSED"
    
    def record_failure(self):
        """Record failed execution"""
        self.failure_count += 1
        self.last_failure_time = import_time()
        
        if self.failure_count >= self.failure_threshold:
            self.state = "OPEN"
            logger.error(f"Circuit breaker OPENED after {self.failure_count} failures")
    
    def __call__(self, func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs) -> T:
            if not self.can_execute():
                raise AutomationError(
                    "Circuit breaker is OPEN",
                    error_code="CIRCUIT_OPEN"
                )
            
            try:
                result = await func(*args, **kwargs)
                self.record_success()
                return result
            except self.expected_exception as e:
                self.record_failure()
                raise
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs) -> T:
            if not self.can_execute():
                raise AutomationError(
                    "Circuit breaker is OPEN",
                    error_code="CIRCUIT_OPEN"
                )
            
            try:
                result = func(*args, **kwargs)
                self.record_success()
                return result
            except self.expected_exception as e:
                self.record_failure()
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper


def import_time():
    """Helper to import time"""
    import time
    return time.time()


# Pre-configured retry decorators
retry_database = with_retry(
    max_attempts=3,
    min_wait=1,
    max_wait=10,
    exceptions=(DatabaseError, Exception)
)

retry_payment = with_retry(
    max_attempts=3,
    min_wait=2,
    max_wait=30,
    exceptions=(PaymentError, httpx.HTTPError)
)

retry_email = with_retry(
    max_attempts=5,
    min_wait=2,
    max_wait=60,
    exceptions=(EmailError, httpx.HTTPError)
)

retry_content = with_retry(
    max_attempts=3,
    min_wait=2,
    max_wait=30,
    exceptions=(ContentError, httpx.HTTPError)
)
