"""
Alert System for Monitoring
Sends alerts via Email, Slack, and logs
"""
from typing import Optional, Dict, Any
from loguru import logger
import httpx
from datetime import datetime
import json

from config.settings import settings


class AlertManager:
    """Centralized alert management system"""
    
    def __init__(self):
        self.slack_webhook = settings.SLACK_WEBHOOK_URL
        self.alert_email = settings.ALERT_EMAIL
        self.app_name = settings.APP_NAME
        self.app_env = settings.APP_ENV
    
    async def send_alert(
        self,
        title: str,
        message: str,
        severity: str = "info",
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Send alert through all configured channels
        
        Args:
            title: Alert title
            message: Alert message
            severity: info, warning, error, critical
            details: Additional context
        """
        # Always log
        self._log_alert(title, message, severity, details)
        
        # Send to Slack if configured
        if self.slack_webhook:
            try:
                await self._send_slack_alert(title, message, severity, details)
            except Exception as e:
                logger.error(f"Failed to send Slack alert: {e}")
        
        # Send email for critical alerts
        if severity in ["error", "critical"] and self.alert_email:
            try:
                await self._send_email_alert(title, message, severity, details)
            except Exception as e:
                logger.error(f"Failed to send email alert: {e}")
    
    def _log_alert(
        self,
        title: str,
        message: str,
        severity: str,
        details: Optional[Dict[str, Any]]
    ):
        """Log alert with appropriate level"""
        log_data = {
            "alert_title": title,
            "alert_message": message,
            "severity": severity,
            "timestamp": datetime.utcnow().isoformat(),
            "environment": self.app_env,
            "details": details or {}
        }
        
        log_message = f"[{severity.upper()}] {title}: {message}"
        
        if severity == "critical":
            logger.critical(log_message, extra=log_data)
        elif severity == "error":
            logger.error(log_message, extra=log_data)
        elif severity == "warning":
            logger.warning(log_message, extra=log_data)
        else:
            logger.info(log_message, extra=log_data)
    
    async def _send_slack_alert(
        self,
        title: str,
        message: str,
        severity: str,
        details: Optional[Dict[str, Any]]
    ):
        """Send alert to Slack webhook"""
        color_map = {
            "info": "#36a64f",
            "warning": "#ff9900",
            "error": "#ff0000",
            "critical": "#990000"
        }
        
        emoji_map = {
            "info": ":information_source:",
            "warning": ":warning:",
            "error": ":x:",
            "critical": ":rotating_light:"
        }
        
        payload = {
            "attachments": [
                {
                    "color": color_map.get(severity, "#808080"),
                    "title": f"{emoji_map.get(severity, '')} {title}",
                    "text": message,
                    "fields": [
                        {
                            "title": "Environment",
                            "value": self.app_env,
                            "short": True
                        },
                        {
                            "title": "Severity",
                            "value": severity.upper(),
                            "short": True
                        },
                        {
                            "title": "Time",
                            "value": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
                            "short": True
                        }
                    ],
                    "footer": self.app_name,
                    "ts": int(datetime.utcnow().timestamp())
                }
            ]
        }
        
        # Add details if provided
        if details:
            details_text = json.dumps(details, indent=2, default=str)
            payload["attachments"][0]["fields"].append({
                "title": "Details",
                "value": f"```{details_text}```",
                "short": False
            })
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.slack_webhook,
                json=payload,
                timeout=10.0
            )
            response.raise_for_status()
    
    async def _send_email_alert(
        self,
        title: str,
        message: str,
        severity: str,
        details: Optional[Dict[str, Any]]
    ):
        """Send alert via email using SendGrid"""
        from sendgrid import SendGridAPIClient
        from sendgrid.helpers.mail import Mail
        
        html_content = f"""
        <h2>{title}</h2>
        <p><strong>Severity:</strong> {severity.upper()}</p>
        <p><strong>Environment:</strong> {self.app_env}</p>
        <p><strong>Time:</strong> {datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")}</p>
        <hr>
        <p>{message}</p>
        """
        
        if details:
            details_html = json.dumps(details, indent=2, default=str)
            html_content += f"<h3>Details:</h3><pre>{details_html}</pre>"
        
        email = Mail(
            from_email=settings.EMAIL_FROM,
            to_emails=self.alert_email,
            subject=f"[{severity.upper()}] {self.app_name} Alert: {title}",
            html_content=html_content
        )
        
        sg = SendGridAPIClient(settings.SENDGRID_API_KEY)
        response = sg.send(email)
        
        if response.status_code not in [200, 201, 202]:
            logger.error(f"Failed to send email alert: {response.status_code}")
    
    # Convenience methods for common alert types
    async def payment_failed(self, customer_email: str, amount: float, error: str):
        """Alert when payment fails"""
        await self.send_alert(
            title="Payment Failed",
            message=f"Payment of ${amount} failed for {customer_email}",
            severity="error",
            details={"customer_email": customer_email, "amount": amount, "error": error}
        )
    
    async def new_customer(self, customer_email: str, plan: str):
        """Alert for new customer signup"""
        await self.send_alert(
            title="New Customer",
            message=f"New customer signed up: {customer_email} ({plan})",
            severity="info",
            details={"email": customer_email, "plan": plan}
        )
    
    async def churn_alert(self, customer_email: str, reason: str = ""):
        """Alert when customer cancels"""
        await self.send_alert(
            title="Customer Churned",
            message=f"Customer canceled subscription: {customer_email}",
            severity="warning",
            details={"email": customer_email, "reason": reason}
        )
    
    async def automation_error(self, automation_type: str, error: str):
        """Alert for automation failures"""
        await self.send_alert(
            title=f"Automation Failed: {automation_type}",
            message=error,
            severity="error",
            details={"automation_type": automation_type}
        )
    
    async def high_volume_alert(self, metric: str, value: int, threshold: int):
        """Alert for unusual volume"""
        await self.send_alert(
            title=f"High Volume: {metric}",
            message=f"{metric} reached {value} (threshold: {threshold})",
            severity="warning",
            details={"metric": metric, "value": value, "threshold": threshold}
        )
    
    async def daily_summary(self, stats: Dict[str, Any]):
        """Send daily summary"""
        await self.send_alert(
            title="Daily Business Summary",
            message=f"Revenue: ${stats.get('revenue', 0)}, New Customers: {stats.get('new_customers', 0)}",
            severity="info",
            details=stats
        )


# Global alert manager instance
alert_manager = AlertManager()
