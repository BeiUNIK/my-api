"""
Tests for Payment Processor Module
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from datetime import datetime

from modules.payment_processor import PaymentProcessor


@pytest.fixture
def mock_stripe():
    """Mock Stripe module"""
    with patch('modules.payment_processor.stripe') as mock:
        yield mock


@pytest.fixture
def mock_supabase():
    """Mock Supabase client"""
    with patch('modules.payment_processor.get_supabase') as mock:
        supabase_mock = Mock()
        mock.return_value = supabase_mock
        yield supabase_mock


@pytest.fixture
def payment_processor(mock_stripe, mock_supabase):
    """Create payment processor with mocked dependencies"""
    with patch('modules.payment_processor.settings') as mock_settings:
        mock_settings.STRIPE_SECRET_KEY = 'sk_test_xxx'
        mock_settings.STRIPE_WEBHOOK_SECRET = 'whsec_xxx'
        mock_settings.STRIPE_PRICE_ID = 'price_xxx'
        return PaymentProcessor()


@pytest.mark.asyncio
async def test_create_checkout_session(payment_processor, mock_stripe):
    """Test creating checkout session"""
    # Arrange
    mock_session = MagicMock()
    mock_session.id = 'session_xxx'
    mock_session.url = 'https://checkout.stripe.com/xxx'
    mock_stripe.checkout.Session.create.return_value = mock_session
    
    # Act
    result = await payment_processor.create_checkout_session(
        customer_email='test@example.com',
        success_url='https://example.com/success',
        cancel_url='https://example.com/cancel'
    )
    
    # Assert
    assert result['session_id'] == 'session_xxx'
    assert 'url' in result
    mock_stripe.checkout.Session.create.assert_called_once()


@pytest.mark.asyncio
async def test_handle_checkout_completed(payment_processor, mock_supabase):
    """Test handling checkout completed webhook"""
    # Arrange
    session_data = {
        'customer_email': 'test@example.com',
        'customer': 'cus_xxx',
        'metadata': {'source': 'checkout'}
    }
    
    mock_supabase.select.return_value = []
    mock_supabase.insert.return_value = {'id': 'customer_xxx'}
    
    # Act
    with patch('modules.payment_processor.onboarding_manager') as mock_onboarding:
        mock_onboarding.start_onboarding = AsyncMock()
        await payment_processor._handle_checkout_completed(session_data)
    
    # Assert
    mock_supabase.insert.assert_called()


@pytest.mark.asyncio
async def test_handle_payment_succeeded(payment_processor, mock_supabase):
    """Test handling successful payment"""
    # Arrange
    invoice_data = {
        'customer': 'cus_xxx',
        'amount_paid': 9700,  # $97.00
        'currency': 'usd',
        'id': 'inv_xxx'
    }
    
    mock_supabase.select.return_value = [{
        'id': 'customer_xxx',
        'email': 'test@example.com'
    }]
    
    # Act
    await payment_processor._handle_payment_succeeded(invoice_data)
    
    # Assert
    mock_supabase.insert.assert_called_once()
    call_args = mock_supabase.insert.call_args[0]
    assert call_args[0] == 'payments'


@pytest.mark.asyncio
async def test_get_revenue_stats(payment_processor, mock_supabase):
    """Test getting revenue statistics"""
    # Arrange
    mock_supabase.select.return_value = [
        {'amount': 97.00, 'status': 'succeeded', 'created_at': datetime.utcnow().isoformat()},
        {'amount': 97.00, 'status': 'succeeded', 'created_at': datetime.utcnow().isoformat()}
    ]
    
    # Act
    result = await payment_processor.get_revenue_stats()
    
    # Assert
    assert result['total_revenue'] == 194.00
    assert result['total_payments'] == 2
