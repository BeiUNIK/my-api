# Deployment Guide - Passive Income Automation System

Complete deployment instructions for the automated passive income system.

## Quick Start (5 Minutes)

### Option 1: Deploy to Vercel (Recommended for Beginners)

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Login to Vercel
vercel login

# 3. Deploy
vercel --prod
```

### Option 2: Deploy to Railway (Recommended for Background Tasks)

```bash
# 1. Install Railway CLI
npm i -g @railway/cli

# 2. Login
railway login

# 3. Initialize project
railway init

# 4. Deploy
railway up
```

---

## Detailed Deployment Steps

### Step 1: Database Setup (Supabase)

1. **Create Supabase Account**
   - Go to [supabase.com](https://supabase.com)
   - Sign up with GitHub
   - Create new project (free tier)

2. **Run Database Schema**
   ```bash
   # Go to Supabase Dashboard > SQL Editor
   # Copy contents of database/schema.sql
   # Paste and run
   ```

3. **Get API Keys**
   - Go to Settings > API
   - Copy `URL` → `SUPABASE_URL`
   - Copy `anon public` → `SUPABASE_KEY`
   - Copy `service_role secret` → `SUPABASE_SERVICE_KEY`

### Step 2: Payment Setup (Stripe)

1. **Create Stripe Account**
   - Go to [stripe.com](https://stripe.com)
   - Complete onboarding

2. **Create Product & Price**
   ```bash
   # In Stripe Dashboard:
   # Products > Add Product
   # Name: Your Digital Product
   # Price: $97 (or your price)
   # Copy Price ID → STRIPE_PRICE_ID
   ```

3. **Get API Keys**
   - Developers > API Keys
   - Copy Secret Key → `STRIPE_SECRET_KEY`

4. **Configure Webhooks**
   ```
   # Developers > Webhooks > Add endpoint
   # Endpoint URL: https://your-domain.com/api/v1/payments/webhook
   # Events to listen to:
   # - checkout.session.completed
   # - invoice.payment_succeeded
   # - invoice.payment_failed
   # - customer.subscription.created
   # - customer.subscription.updated
   # - customer.subscription.deleted
   # Copy Signing Secret → STRIPE_WEBHOOK_SECRET
   ```

### Step 3: Email Setup (SendGrid)

1. **Create SendGrid Account**
   - Go to [sendgrid.com](https://sendgrid.com)
   - Sign up (free tier: 100 emails/day)

2. **Verify Sender**
   - Settings > Sender Authentication
   - Verify your domain or single sender

3. **Get API Key**
   - Settings > API Keys > Create API Key
   - Copy key → `SENDGRID_API_KEY`

### Step 4: AI Content Setup (OpenAI)

1. **Create OpenAI Account**
   - Go to [platform.openai.com](https://platform.openai.com)
   - Sign up and add payment method

2. **Get API Key**
   - API Keys > Create new secret key
   - Copy key → `OPENAI_API_KEY`

### Step 5: Deploy Application

#### Vercel Deployment

```bash
# 1. Fork/clone this repository

# 2. Install Vercel CLI
npm i -g vercel

# 3. Configure environment variables
vercel env add SUPABASE_URL
vercel env add SUPABASE_KEY
vercel env add SUPABASE_SERVICE_KEY
vercel env add STRIPE_SECRET_KEY
vercel env add STRIPE_WEBHOOK_SECRET
vercel env add STRIPE_PRICE_ID
vercel env add SENDGRID_API_KEY
vercel env add EMAIL_FROM
vercel env add OPENAI_API_KEY
vercel env add SECRET_KEY

# 4. Deploy
vercel --prod
```

#### Railway Deployment (With Background Tasks)

```bash
# 1. Install Railway CLI
npm i -g @railway/cli

# 2. Login
railway login

# 3. Create project
railway init

# 4. Add Redis (for Celery)
railway add --plugin redis

# 5. Add environment variables in Railway Dashboard
# Project > Variables > Raw Editor
# Paste all variables from .env

# 6. Deploy
railway up

# 7. Scale workers (optional)
railway scale worker --replicas 1
```

---

## Cost Optimization

### Free Tier Limits

| Service | Free Tier | Monthly Cost |
|---------|-----------|--------------|
| **Vercel** | 100GB bandwidth, 10s execution | $0 |
| **Railway** | $5 credit/month | $0-5 |
| **Supabase** | 500MB DB, 2GB bandwidth | $0 |
| **Stripe** | No monthly fee, 2.9% + 30¢ per transaction | Per transaction |
| **SendGrid** | 100 emails/day | $0 |
| **OpenAI** | GPT-3.5: $0.002/1K tokens | ~$5-20 |
| **Redis** | Upstash: 10K commands/day | $0 |
| **Sentry** | 5K errors/month | $0 |

### Scaling Triggers

```python
# When to upgrade:

# 1. Database (Supabase)
# - Current: 500MB free
# - Upgrade at: 400MB usage
# - Cost: $25/month for 8GB

# 2. Email (SendGrid)
# - Current: 100/day free
# - Upgrade at: 80/day average
# - Cost: $15/month for 40K emails

# 3. AI Content (OpenAI)
# - Monitor usage in dashboard
# - Set billing limit: $50/month
# - Consider: GPT-3.5 for cost savings

# 4. Hosting (Vercel/Railway)
# - Vercel: Upgrade at 90GB bandwidth
# - Railway: Pay-as-you-go after $5 credit
```

---

## Monitoring & Alerts

### Setup Slack Alerts

1. Create Slack app: https://api.slack.com/apps
2. Enable Incoming Webhooks
3. Copy webhook URL to `SLACK_WEBHOOK_URL`

### Setup Sentry Error Tracking

1. Create account: https://sentry.io
2. Create new project (Python/FastAPI)
3. Copy DSN to `SENTRY_DSN`

### Health Check Endpoint

```bash
# Test your deployment
curl https://your-domain.com/health

# Expected response:
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00",
  "database": "connected",
  "services": {
    "stripe": "configured",
    "sendgrid": "configured",
    "openai": "configured"
  }
}
```

---

## API Endpoints Reference

### Lead Capture
```
POST /api/v1/leads/capture          # Capture new lead
GET  /api/v1/leads/verify           # Verify email
GET  /api/v1/leads/stats            # Lead statistics
```

### Payments
```
POST /api/v1/payments/checkout      # Create checkout session
POST /api/v1/payments/portal        # Customer portal
POST /api/v1/payments/webhook       # Stripe webhook
GET  /api/v1/payments/stats         # Revenue stats
```

### Content
```
POST /api/v1/content/generate       # Generate AI content
POST /api/v1/content/schedule       # Schedule content
POST /api/v1/content/{id}/publish   # Publish content
GET  /api/v1/content/stats          # Content stats
GET  /api/v1/content/ideas          # Get content ideas
```

### Onboarding
```
POST /api/v1/onboarding/{id}/start          # Start onboarding
POST /api/v1/onboarding/{id}/complete/{n}   # Complete step
GET  /api/v1/onboarding/{id}/progress       # Get progress
GET  /api/v1/onboarding/stalled             # Stalled customers
```

### Automation
```
POST /api/v1/automation/run-content-pipeline    # Run content pipeline
POST /api/v1/automation/send-onboarding-nudges  # Send nudges
```

### Admin
```
GET  /api/v1/admin/dashboard            # Dashboard metrics
POST /api/v1/admin/send-test-alert      # Test alerts
```

---

## Troubleshooting

### Common Issues

**1. Database Connection Failed**
```bash
# Check Supabase URL and keys
# Ensure IP is not restricted in Supabase settings
```

**2. Stripe Webhook Not Working**
```bash
# Verify webhook URL is correct
# Check STRIPE_WEBHOOK_SECRET is set
# Test webhook in Stripe Dashboard
```

**3. Emails Not Sending**
```bash
# Verify SendGrid API key
# Check sender email is verified
# Review SendGrid activity feed
```

**4. AI Content Not Generating**
```bash
# Check OpenAI API key
# Verify billing is set up
# Check usage limits
```

---

## Security Checklist

- [ ] Change `SECRET_KEY` to random 32+ character string
- [ ] Use `SUPABASE_SERVICE_KEY` only server-side
- [ ] Store all secrets in environment variables
- [ ] Enable Row Level Security in Supabase
- [ ] Use HTTPS only (Vercel/Railway provide this)
- [ ] Set up Sentry for error tracking
- [ ] Configure Stripe webhook signature verification
- [ ] Rate limit API endpoints (add middleware)

---

## Next Steps

1. **Connect Your Frontend**
   - Use the API endpoints in your landing page
   - Add lead capture forms
   - Implement checkout flow

2. **Customize Email Templates**
   - Edit email content in `modules/lead_capture.py`
   - Add your branding

3. **Set Up Analytics**
   - Add Google Analytics
   - Track conversion rates

4. **Monitor & Optimize**
   - Check dashboard daily
   - Review automated emails
   - Optimize based on data
