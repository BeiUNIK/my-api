"""
Application Configuration & Settings
Production-ready configuration with environment variable validation
"""
from pydantic_settings import BaseSettings
from pydantic import Field, validator
from typing import Optional, List
import os


class Settings(BaseSettings):
    """Application settings with validation"""
    
    # Application
    APP_NAME: str = Field(default="Passive Income Automation", env="APP_NAME")
    APP_ENV: str = Field(default="development", env="APP_ENV")
    DEBUG: bool = Field(default=False, env="DEBUG")
    SECRET_KEY: str = Field(default="your-secret-key-change-in-production", env="SECRET_KEY")
    
    # API Configuration
    API_V1_PREFIX: str = "/api/v1"
    ALLOWED_HOSTS: List[str] = Field(default=["*"], env="ALLOWED_HOSTS")
    
    # Supabase Configuration
    SUPABASE_URL: str = Field(default="", env="SUPABASE_URL")
    SUPABASE_KEY: str = Field(default="", env="SUPABASE_KEY")
    SUPABASE_SERVICE_KEY: str = Field(default="", env="SUPABASE_SERVICE_KEY")
    
    # Stripe Configuration
    STRIPE_SECRET_KEY: str = Field(default="", env="STRIPE_SECRET_KEY")
    STRIPE_WEBHOOK_SECRET: str = Field(default="", env="STRIPE_WEBHOOK_SECRET")
    STRIPE_PRICE_ID: str = Field(default="", env="STRIPE_PRICE_ID")
    
    # Email Configuration (SendGrid)
    SENDGRID_API_KEY: str = Field(default="", env="SENDGRID_API_KEY")
    EMAIL_FROM: str = Field(default="noreply@yourdomain.com", env="EMAIL_FROM")
    EMAIL_FROM_NAME: str = Field(default="Your Business", env="EMAIL_FROM_NAME")
    
    # OpenAI Configuration
    OPENAI_API_KEY: str = Field(default="", env="OPENAI_API_KEY")
    OPENAI_MODEL: str = Field(default="gpt-4", env="OPENAI_MODEL")
    
    # Redis Configuration (for Celery)
    REDIS_URL: str = Field(default="redis://localhost:6379/0", env="REDIS_URL")
    
    # Sentry Configuration (Error Tracking)
    SENTRY_DSN: Optional[str] = Field(default=None, env="SENTRY_DSN")
    
    # Slack Alerts
    SLACK_WEBHOOK_URL: Optional[str] = Field(default=None, env="SLACK_WEBHOOK_URL")
    
    # Monitoring
    ALERT_EMAIL: Optional[str] = Field(default=None, env="ALERT_EMAIL")
    
    # Business Logic
    PRODUCT_NAME: str = Field(default="Digital Product", env="PRODUCT_NAME")
    PRODUCT_PRICE: float = Field(default=97.0, env="PRODUCT_PRICE")
    TRIAL_DAYS: int = Field(default=7, env="TRIAL_DAYS")
    
    # Content Generation
    CONTENT_SCHEDULE_HOUR: int = Field(default=9, env="CONTENT_SCHEDULE_HOUR")
    MAX_CONTENT_PER_DAY: int = Field(default=3, env="MAX_CONTENT_PER_DAY")
    
    @validator('APP_ENV')
    def validate_env(cls, v):
        allowed = ['development', 'staging', 'production']
        if v not in allowed:
            raise ValueError(f'APP_ENV must be one of {allowed}')
        return v
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()


def get_settings() -> Settings:
    """Get application settings"""
    return settings
