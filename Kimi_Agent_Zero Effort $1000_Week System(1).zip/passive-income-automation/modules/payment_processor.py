"""
Payment Processing & Webhook Handler
Handles Stripe payments, subscriptions, and webhook events
"""
from typing import Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from fastapi import Request, HTTPException, Header
import stripe
from loguru import logger

from database.supabase_client import get_supabase
from utils.error_handler import with_retry, PaymentError
from utils.alerts import alert_manager
from config.settings import settings


class PaymentIntent(BaseModel):
    """Payment intent model"""
    amount: int  # Amount in cents
    currency: str = "usd"
    customer_email: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = {}


class SubscriptionCreate(BaseModel):
    """Subscription creation model"""
    customer_email: str
    price_id: Optional[str] = None
    trial_days: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = {}


class PaymentProcessor:
    """Stripe payment processor with webhook handling"""
    
    def __init__(self):
        stripe.api_key = settings.STRIPE_SECRET_KEY
        self.webhook_secret = settings.STRIPE_WEBHOOK_SECRET
        self.default_price_id = settings.STRIPE_PRICE_ID
        self.supabase = get_supabase()
    
    async def create_checkout_session(
        self,
        customer_email: str,
        success_url: str,
        cancel_url: str,
        price_id: Optional[str] = None,
        mode: str = "subscription"
    ) -> Dict[str, Any]:
        """
        Create Stripe Checkout Session
        
        Args:
            customer_email: Customer email
            success_url: Redirect URL after successful payment
            cancel_url: Redirect URL after cancelled payment
            price_id: Stripe price ID (uses default if not provided)
            mode: 'subscription' or 'payment'
            
        Returns:
            Checkout session details
        """
        try:
            # Check if customer already exists
            existing_customer = await self._get_customer_by_email(customer_email)
            
            session_params = {
                "payment_method_types": ["card"],
                "customer_email": None if existing_customer else customer_email,
                "customer": existing_customer.get('stripe_customer_id') if existing_customer else None,
                "line_items": [{
                    "price": price_id or self.default_price_id,
                    "quantity": 1,
                }],
                "mode": mode,
                "success_url": success_url,
                "cancel_url": cancel_url,
                "metadata": {
                    "customer_email": customer_email,
                    "source": "checkout"
                }
            }
            
            session = stripe.checkout.Session.create(**session_params)
            
            logger.info(f"Checkout session created for {customer_email}: {session.id}")
            
            return {
                "session_id": session.id,
                "url": session.url,
                "customer_email": customer_email
            }
            
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating checkout: {e}")
            raise PaymentError(f"Failed to create checkout: {str(e)}")
    
    async def create_customer_portal_session(
        self,
        customer_id: str,
        return_url: str
    ) -> Dict[str, Any]:
        """
        Create customer portal session for subscription management
        
        Args:
            customer_id: Stripe customer ID
            return_url: URL to return to after portal
            
        Returns:
            Portal session URL
        """
        try:
            session = stripe.billing_portal.Session.create(
                customer=customer_id,
                return_url=return_url
            )
            
            return {"url": session.url}
            
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating portal: {e}")
            raise PaymentError(f"Failed to create portal: {str(e)}")
    
    async def handle_webhook(
        self,
        request: Request,
        stripe_signature: str
    ) -> Dict[str, Any]:
        """
        Handle Stripe webhook events
        
        Args:
            request: FastAPI request object
            stripe_signature: Stripe signature header
            
        Returns:
            Processing result
        """
        payload = await request.body()
        
        try:
            event = stripe.Webhook.construct_event(
                payload, stripe_signature, self.webhook_secret
            )
        except ValueError as e:
            logger.error(f"Invalid payload: {e}")
            raise HTTPException(status_code=400, detail="Invalid payload")
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"Invalid signature: {e}")
            raise HTTPException(status_code=400, detail="Invalid signature")
        
        # Store webhook event
        await self._store_webhook_event(event)
        
        # Process event
        event_type = event['type']
        event_data = event['data']['object']
        
        logger.info(f"Processing webhook: {event_type}")
        
        handlers = {
            'checkout.session.completed': self._handle_checkout_completed,
            'invoice.payment_succeeded': self._handle_payment_succeeded,
            'invoice.payment_failed': self._handle_payment_failed,
            'customer.subscription.created': self._handle_subscription_created,
            'customer.subscription.updated': self._handle_subscription_updated,
            'customer.subscription.deleted': self._handle_subscription_deleted,
            'customer.subscription.trial_will_end': self._handle_trial_ending,
        }
        
        handler = handlers.get(event_type)
        if handler:
            try:
                await handler(event_data)
                await self._mark_webhook_processed(event['id'])
                return {"status": "processed", "event": event_type}
            except Exception as e:
                logger.error(f"Error handling {event_type}: {e}")
                await self._mark_webhook_error(event['id'], str(e))
                raise HTTPException(status_code=500, detail="Processing error")
        else:
            logger.info(f"Unhandled event type: {event_type}")
            return {"status": "ignored", "event": event_type}
    
    async def _handle_checkout_completed(self, session: Dict[str, Any]):
        """Handle successful checkout"""
        customer_email = session.get('customer_email') or session.get('metadata', {}).get('customer_email')
        stripe_customer_id = session.get('customer')
        
        if not customer_email:
            logger.warning("No customer email in checkout session")
            return
        
        # Get or create customer
        customer = await self._get_or_create_customer(
            email=customer_email,
            stripe_customer_id=stripe_customer_id
        )
        
        # Update customer with subscription info
        await self.supabase.update(
            "customers",
            customer['id'],
            {
                "subscription_status": "active",
                "subscription_start_date": datetime.utcnow().isoformat(),
                "updated_at": datetime.utcnow().isoformat()
            }
        )
        
        # Trigger onboarding
        from modules.onboarding import onboarding_manager
        await onboarding_manager.start_onboarding(customer['id'])
        
        # Send welcome email
        await alert_manager.new_customer(customer_email, "subscription")
        
        logger.info(f"Checkout completed for {customer_email}")
    
    async def _handle_payment_succeeded(self, invoice: Dict[str, Any]):
        """Handle successful payment"""
        stripe_customer_id = invoice.get('customer')
        amount_paid = invoice.get('amount_paid', 0) / 100  # Convert cents to dollars
        
        # Get customer
        customer = await self._get_customer_by_stripe_id(stripe_customer_id)
        
        if not customer:
            logger.warning(f"Customer not found: {stripe_customer_id}")
            return
        
        # Record payment
        payment_record = {
            "customer_id": customer['id'],
            "stripe_invoice_id": invoice.get('id'),
            "amount": amount_paid,
            "currency": invoice.get('currency', 'usd').upper(),
            "status": "succeeded",
            "payment_method": invoice.get('payment_intent'),
            "description": invoice.get('description'),
            "metadata": {
                "invoice_number": invoice.get('number'),
                "billing_reason": invoice.get('billing_reason')
            },
            "created_at": datetime.utcnow().isoformat()
        }
        
        await self.supabase.insert("payments", payment_record)
        
        logger.info(f"Payment recorded: ${amount_paid} for {customer['email']}")
    
    async def _handle_payment_failed(self, invoice: Dict[str, Any]):
        """Handle failed payment"""
        stripe_customer_id = invoice.get('customer')
        amount_due = invoice.get('amount_due', 0) / 100
        
        customer = await self._get_customer_by_stripe_id(stripe_customer_id)
        
        if customer:
            # Record failed payment
            payment_record = {
                "customer_id": customer['id'],
                "stripe_invoice_id": invoice.get('id'),
                "amount": amount_due,
                "currency": invoice.get('currency', 'usd').upper(),
                "status": "failed",
                "created_at": datetime.utcnow().isoformat()
            }
            
            await self.supabase.insert("payments", payment_record)
            
            # Send alert
            await alert_manager.payment_failed(
                customer_email=customer['email'],
                amount=amount_due,
                error=invoice.get('last_finalization_error', {}).get('message', 'Unknown error')
            )
            
            logger.warning(f"Payment failed: ${amount_due} for {customer['email']}")
    
    async def _handle_subscription_created(self, subscription: Dict[str, Any]):
        """Handle new subscription"""
        stripe_customer_id = subscription.get('customer')
        customer = await self._get_customer_by_stripe_id(stripe_customer_id)
        
        if not customer:
            return
        
        subscription_record = {
            "customer_id": customer['id'],
            "stripe_subscription_id": subscription.get('id'),
            "stripe_price_id": subscription.get('items', {}).get('data', [{}])[0].get('price', {}).get('id'),
            "status": subscription.get('status'),
            "current_period_start": datetime.fromtimestamp(subscription.get('current_period_start')).isoformat(),
            "current_period_end": datetime.fromtimestamp(subscription.get('current_period_end')).isoformat(),
            "amount": subscription.get('items', {}).get('data', [{}])[0].get('price', {}).get('unit_amount', 0) / 100,
            "currency": subscription.get('currency', 'usd').upper(),
            "created_at": datetime.utcnow().isoformat()
        }
        
        await self.supabase.insert("subscriptions", subscription_record)
        
        logger.info(f"Subscription created for {customer['email']}")
    
    async def _handle_subscription_updated(self, subscription: Dict[str, Any]):
        """Handle subscription update"""
        stripe_subscription_id = subscription.get('id')
        
        # Find subscription in database
        subs = await self.supabase.select(
            "subscriptions",
            {"stripe_subscription_id": stripe_subscription_id}
        )
        
        if subs:
            await self.supabase.update(
                "subscriptions",
                subs[0]['id'],
                {
                    "status": subscription.get('status'),
                    "current_period_start": datetime.fromtimestamp(subscription.get('current_period_start')).isoformat(),
                    "current_period_end": datetime.fromtimestamp(subscription.get('current_period_end')).isoformat(),
                    "cancel_at_period_end": subscription.get('cancel_at_period_end', False),
                    "updated_at": datetime.utcnow().isoformat()
                }
            )
            
            logger.info(f"Subscription updated: {stripe_subscription_id}")
    
    async def _handle_subscription_deleted(self, subscription: Dict[str, Any]):
        """Handle subscription cancellation"""
        stripe_subscription_id = subscription.get('id')
        
        subs = await self.supabase.select(
            "subscriptions",
            {"stripe_subscription_id": stripe_subscription_id}
        )
        
        if subs:
            sub = subs[0]
            
            # Update subscription
            await self.supabase.update(
                "subscriptions",
                sub['id'],
                {
                    "status": "canceled",
                    "canceled_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat()
                }
            )
            
            # Update customer
            await self.supabase.update(
                "customers",
                sub['customer_id'],
                {
                    "subscription_status": "canceled",
                    "subscription_end_date": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat()
                }
            )
            
            # Get customer for alert
            customers = await self.supabase.select("customers", {"id": sub['customer_id']})
            if customers:
                await alert_manager.churn_alert(customers[0]['email'])
            
            logger.info(f"Subscription canceled: {stripe_subscription_id}")
    
    async def _handle_trial_ending(self, subscription: Dict[str, Any]):
        """Handle trial ending notification"""
        stripe_customer_id = subscription.get('customer')
        customer = await self._get_customer_by_stripe_id(stripe_customer_id)
        
        if customer:
            # Send trial ending email
            from modules.lead_capture import EmailSender
            email_sender = EmailSender()
            
            await email_sender.send_email(
                to_email=customer['email'],
                subject="Your trial ends soon - here's what happens next",
                html_content=f"""
                <html>
                <body>
                    <h1>Your Trial Ends Soon</h1>
                    <p>Hi {customer.get('first_name', '')},</p>
                    <p>Your trial period ends in 3 days. To continue enjoying our service, no action is needed - your subscription will automatically begin.</p>
                    <p>Questions? Reply to this email.</p>
                </body>
                </html>
                """,
                customer_id=customer['id'],
                campaign_type="trial_ending"
            )
            
            logger.info(f"Trial ending notification sent to {customer['email']}")
    
    @with_retry(max_attempts=3)
    async def _get_customer_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Get customer by email"""
        customers = await self.supabase.select("customers", {"email": email}, limit=1)
        return customers[0] if customers else None
    
    @with_retry(max_attempts=3)
    async def _get_customer_by_stripe_id(self, stripe_id: str) -> Optional[Dict[str, Any]]:
        """Get customer by Stripe ID"""
        customers = await self.supabase.select("customers", {"stripe_customer_id": stripe_id}, limit=1)
        return customers[0] if customers else None
    
    async def _get_or_create_customer(
        self,
        email: str,
        stripe_customer_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get existing customer or create new one"""
        existing = await self._get_customer_by_email(email)
        
        if existing:
            # Update Stripe ID if provided
            if stripe_customer_id and not existing.get('stripe_customer_id'):
                await self.supabase.update(
                    "customers",
                    existing['id'],
                    {"stripe_customer_id": stripe_customer_id}
                )
                existing['stripe_customer_id'] = stripe_customer_id
            return existing
        
        # Create new customer
        customer_record = {
            "email": email,
            "stripe_customer_id": stripe_customer_id,
            "status": "active",
            "created_at": datetime.utcnow().isoformat()
        }
        
        return await self.supabase.insert("customers", customer_record)
    
    async def _store_webhook_event(self, event: Dict[str, Any]):
        """Store webhook event for audit"""
        webhook_record = {
            "source": "stripe",
            "event_type": event['type'],
            "event_id": event['id'],
            "payload": event,
            "processed": False,
            "created_at": datetime.utcnow().isoformat()
        }
        
        await self.supabase.insert("webhook_events", webhook_record)
    
    async def _mark_webhook_processed(self, event_id: str):
        """Mark webhook as processed"""
        events = await self.supabase.select("webhook_events", {"event_id": event_id})
        if events:
            await self.supabase.update(
                "webhook_events",
                events[0]['id'],
                {
                    "processed": True,
                    "processed_at": datetime.utcnow().isoformat()
                }
            )
    
    async def _mark_webhook_error(self, event_id: str, error: str):
        """Mark webhook with error"""
        events = await self.supabase.select("webhook_events", {"event_id": event_id})
        if events:
            await self.supabase.update(
                "webhook_events",
                events[0]['id'],
                {
                    "error_message": error,
                    "retry_count": events[0].get('retry_count', 0) + 1
                }
            )
    
    async def get_revenue_stats(self) -> Dict[str, Any]:
        """Get revenue statistics"""
        try:
            payments = await self.supabase.select("payments", {"status": "succeeded"}, limit=1000)
            
            total_revenue = sum(p.get('amount', 0) for p in payments)
            
            # This month's revenue
            from datetime import datetime, timedelta
            month_start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0)
            month_payments = [
                p for p in payments 
                if datetime.fromisoformat(p['created_at'].replace('Z', '+00:00')) >= month_start
            ]
            month_revenue = sum(p.get('amount', 0) for p in month_payments)
            
            return {
                "total_revenue": round(total_revenue, 2),
                "month_revenue": round(month_revenue, 2),
                "total_payments": len(payments),
                "month_payments": len(month_payments),
                "average_order_value": round(total_revenue / len(payments), 2) if payments else 0
            }
        except Exception as e:
            logger.error(f"Failed to get revenue stats: {e}")
            return {}


# Global instance
payment_processor = PaymentProcessor()
