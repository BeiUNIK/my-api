"""
Customer Onboarding Automation
Automated onboarding flow for new customers
"""
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from pydantic import BaseModel
from loguru import logger

from database.supabase_client import get_supabase
from utils.error_handler import with_retry
from utils.alerts import alert_manager
from config.settings import settings


class OnboardingStep(BaseModel):
    """Onboarding step model"""
    step_number: int
    step_name: str
    title: str
    description: str
    action_required: bool
    action_url: Optional[str] = None
    action_text: Optional[str] = None
    estimated_time: Optional[str] = None


class OnboardingProgress(BaseModel):
    """Onboarding progress model"""
    customer_id: str
    current_step: int
    total_steps: int
    completed_steps: List[int]
    completion_percentage: float
    started_at: datetime
    estimated_completion: Optional[datetime] = None


class OnboardingManager:
    """Manages automated customer onboarding"""
    
    def __init__(self):
        self.supabase = get_supabase()
        
        # Define onboarding steps
        self.steps = [
            OnboardingStep(
                step_number=1,
                step_name="welcome",
                title="Welcome to Your Journey!",
                description="Get oriented with your new account and what you can achieve.",
                action_required=False,
                estimated_time="2 min"
            ),
            OnboardingStep(
                step_number=2,
                step_name="profile_setup",
                title="Complete Your Profile",
                description="Tell us a bit about yourself so we can personalize your experience.",
                action_required=True,
                action_url="/dashboard/profile",
                action_text="Complete Profile",
                estimated_time="5 min"
            ),
            OnboardingStep(
                step_number=3,
                step_name="first_action",
                title="Take Your First Action",
                description="Complete your first task to see how everything works.",
                action_required=True,
                action_url="/dashboard/quickstart",
                action_text="Start Quick Guide",
                estimated_time="10 min"
            ),
            OnboardingStep(
                step_number=4,
                step_name="connect_integrations",
                title="Connect Your Tools",
                description="Integrate with your favorite tools for seamless workflow.",
                action_required=True,
                action_url="/dashboard/integrations",
                action_text="Connect Tools",
                estimated_time="5 min"
            ),
            OnboardingStep(
                step_number=5,
                step_name="explore_features",
                title="Explore Key Features",
                description="Discover the features that will help you achieve your goals.",
                action_required=True,
                action_url="/dashboard/features",
                action_text="Explore Features",
                estimated_time="15 min"
            ),
            OnboardingStep(
                step_number=6,
                step_name="join_community",
                title="Join the Community",
                description="Connect with other members and get support when you need it.",
                action_required=True,
                action_url="/community",
                action_text="Join Community",
                estimated_time="3 min"
            ),
            OnboardingStep(
                step_number=7,
                step_name="first_win",
                title="Celebrate Your First Win!",
                description="You've completed onboarding! Here's what to do next.",
                action_required=False,
                estimated_time="2 min"
            )
        ]
    
    async def start_onboarding(self, customer_id: str) -> Dict[str, Any]:
        """
        Start onboarding for a new customer
        
        Args:
            customer_id: Customer ID
            
        Returns:
            Onboarding session details
        """
        try:
            # Create onboarding steps for customer
            for step in self.steps:
                step_record = {
                    "customer_id": customer_id,
                    "step_number": step.step_number,
                    "step_name": step.step_name,
                    "completed": False,
                    "created_at": datetime.utcnow().isoformat()
                }
                
                await self.supabase.insert("onboarding_steps", step_record)
            
            # Update customer
            await self.supabase.update(
                "customers",
                customer_id,
                {
                    "onboarding_step": 1,
                    "onboarding_completed": False,
                    "updated_at": datetime.utcnow().isoformat()
                }
            )
            
            # Send welcome email
            await self._send_onboarding_welcome(customer_id)
            
            # Schedule follow-up emails
            await self._schedule_onboarding_emails(customer_id)
            
            logger.info(f"Onboarding started for customer: {customer_id}")
            
            return {
                "customer_id": customer_id,
                "current_step": 1,
                "total_steps": len(self.steps),
                "started": True
            }
            
        except Exception as e:
            logger.error(f"Failed to start onboarding: {e}")
            await alert_manager.automation_error("onboarding_start", str(e))
            raise
    
    async def complete_step(self, customer_id: str, step_number: int) -> Dict[str, Any]:
        """
        Mark an onboarding step as complete
        
        Args:
            customer_id: Customer ID
            step_number: Step number to complete
            
        Returns:
            Updated progress
        """
        try:
            # Find the step
            steps = await self.supabase.select(
                "onboarding_steps",
                {"customer_id": customer_id, "step_number": step_number}
            )
            
            if not steps:
                logger.warning(f"Step {step_number} not found for customer {customer_id}")
                return {"error": "Step not found"}
            
            step = steps[0]
            
            # Mark as completed
            await self.supabase.update(
                "onboarding_steps",
                step['id'],
                {
                    "completed": True,
                    "completed_at": datetime.utcnow().isoformat()
                }
            )
            
            # Update customer progress
            next_step = step_number + 1
            
            if next_step > len(self.steps):
                # Onboarding complete
                await self.supabase.update(
                    "customers",
                    customer_id,
                    {
                        "onboarding_step": next_step,
                        "onboarding_completed": True,
                        "updated_at": datetime.utcnow().isoformat()
                    }
                )
                
                # Send completion email
                await self._send_onboarding_complete(customer_id)
                
                logger.info(f"Onboarding completed for customer: {customer_id}")
                
            else:
                await self.supabase.update(
                    "customers",
                    customer_id,
                    {
                        "onboarding_step": next_step,
                        "updated_at": datetime.utcnow().isoformat()
                    }
                )
                
                # Send next step email
                await self._send_step_reminder(customer_id, next_step)
                
                logger.info(f"Step {step_number} completed for customer: {customer_id}")
            
            # Return progress
            return await self.get_progress(customer_id)
            
        except Exception as e:
            logger.error(f"Failed to complete step: {e}")
            raise
    
    async def get_progress(self, customer_id: str) -> Dict[str, Any]:
        """
        Get customer onboarding progress
        
        Args:
            customer_id: Customer ID
            
        Returns:
            Progress details
        """
        try:
            # Get customer
            customers = await self.supabase.select("customers", {"id": customer_id})
            if not customers:
                return {"error": "Customer not found"}
            
            customer = customers[0]
            
            # Get completed steps
            steps = await self.supabase.select(
                "onboarding_steps",
                {"customer_id": customer_id}
            )
            
            completed_steps = [s['step_number'] for s in steps if s.get('completed')]
            current_step = customer.get('onboarding_step', 1)
            total_steps = len(self.steps)
            
            completion_percentage = (len(completed_steps) / total_steps) * 100
            
            # Get next step details
            next_step = None
            if current_step <= total_steps:
                step_data = self.steps[current_step - 1]
                next_step = {
                    "number": step_data.step_number,
                    "name": step_data.step_name,
                    "title": step_data.title,
                    "description": step_data.description,
                    "action_required": step_data.action_required,
                    "action_url": step_data.action_url,
                    "action_text": step_data.action_text,
                    "estimated_time": step_data.estimated_time
                }
            
            return {
                "customer_id": customer_id,
                "current_step": current_step,
                "total_steps": total_steps,
                "completed_steps": completed_steps,
                "completion_percentage": round(completion_percentage, 1),
                "onboarding_completed": customer.get('onboarding_completed', False),
                "next_step": next_step,
                "started_at": customer.get('created_at')
            }
            
        except Exception as e:
            logger.error(f"Failed to get progress: {e}")
            return {"error": str(e)}
    
    async def _send_onboarding_welcome(self, customer_id: str):
        """Send onboarding welcome email"""
        try:
            customers = await self.supabase.select("customers", {"id": customer_id})
            if not customers:
                return
            
            customer = customers[0]
            first_name = customer.get('first_name', '')
            
            from modules.lead_capture import EmailSender
            email_sender = EmailSender()
            
            html_content = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h1 style="color: #27ae60;">Welcome to {settings.PRODUCT_NAME}!</h1>
                    
                    <p>Hi{f' {first_name}' if first_name else ''},</p>
                    
                    <p>Thank you for joining! We're excited to help you achieve your goals.</p>
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Your Onboarding Journey</h3>
                        <p>We've prepared a 7-step onboarding process to help you get the most out of your subscription:</p>
                        <ol>
                            <li>Welcome & Orientation</li>
                            <li>Complete Your Profile</li>
                            <li>Take Your First Action</li>
                            <li>Connect Your Tools</li>
                            <li>Explore Key Features</li>
                            <li>Join the Community</li>
                            <li>Celebrate Your First Win!</li>
                        </ol>
                        <p><strong>Estimated time:</strong> ~45 minutes total</p>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="https://yourdomain.com/dashboard/onboarding" 
                           style="background: #3498db; color: white; padding: 15px 30px; 
                                  text-decoration: none; border-radius: 5px; display: inline-block;">
                            Start Onboarding
                        </a>
                    </div>
                    
                    <p>Need help? Reply to this email anytime.</p>
                    
                    <p>Best regards,<br>The {settings.PRODUCT_NAME} Team</p>
                </div>
            </body>
            </html>
            """
            
            await email_sender.send_email(
                to_email=customer['email'],
                subject=f"Welcome to {settings.PRODUCT_NAME}! Let's get you started",
                html_content=html_content,
                customer_id=customer_id,
                campaign_type="onboarding_welcome"
            )
            
        except Exception as e:
            logger.error(f"Failed to send onboarding welcome: {e}")
    
    async def _send_step_reminder(self, customer_id: str, step_number: int):
        """Send reminder for next step"""
        try:
            if step_number > len(self.steps):
                return
            
            step = self.steps[step_number - 1]
            
            customers = await self.supabase.select("customers", {"id": customer_id})
            if not customers:
                return
            
            customer = customers[0]
            
            from modules.lead_capture import EmailSender
            email_sender = EmailSender()
            
            html_content = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2>Ready for Step {step_number}?</h2>
                    
                    <p>Hi{f' {customer.get("first_name", "")}' if customer.get('first_name') else ''},</p>
                    
                    <p>Great progress! You're ready for the next step:</p>
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">{step.title}</h3>
                        <p>{step.description}</p>
                        <p><strong>Estimated time:</strong> {step.estimated_time}</p>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="https://yourdomain.com{step.action_url}" 
                           style="background: #3498db; color: white; padding: 15px 30px; 
                                  text-decoration: none; border-radius: 5px; display: inline-block;">
                            {step.action_text}
                        </a>
                    </div>
                    
                    <p>Keep up the great work!</p>
                </div>
            </body>
            </html>
            """
            
            await email_sender.send_email(
                to_email=customer['email'],
                subject=f"Step {step_number}: {step.title}",
                html_content=html_content,
                customer_id=customer_id,
                campaign_type="onboarding_reminder"
            )
            
        except Exception as e:
            logger.error(f"Failed to send step reminder: {e}")
    
    async def _send_onboarding_complete(self, customer_id: str):
        """Send onboarding completion email"""
        try:
            customers = await self.supabase.select("customers", {"id": customer_id})
            if not customers:
                return
            
            customer = customers[0]
            
            from modules.lead_capture import EmailSender
            email_sender = EmailSender()
            
            html_content = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h1 style="color: #27ae60;">🎉 Congratulations!</h1>
                    
                    <p>Hi{f' {customer.get("first_name", "")}' if customer.get('first_name') else ''},</p>
                    
                    <p>You've completed your onboarding! You're now ready to make the most of {settings.PRODUCT_NAME}.</p>
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">What's Next?</h3>
                        <ul>
                            <li>Explore advanced features in your dashboard</li>
                            <li>Join our community discussions</li>
                            <li>Schedule your first strategy session</li>
                            <li>Check out our resource library</li>
                        </ul>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="https://yourdomain.com/dashboard" 
                           style="background: #27ae60; color: white; padding: 15px 30px; 
                                  text-decoration: none; border-radius: 5px; display: inline-block;">
                            Go to Dashboard
                        </a>
                    </div>
                    
                    <p>We're here to support you every step of the way!</p>
                </div>
            </body>
            </html>
            """
            
            await email_sender.send_email(
                to_email=customer['email'],
                subject="🎉 Onboarding Complete! Here's what's next...",
                html_content=html_content,
                customer_id=customer_id,
                campaign_type="onboarding_complete"
            )
            
        except Exception as e:
            logger.error(f"Failed to send completion email: {e}")
    
    async def _schedule_onboarding_emails(self, customer_id: str):
        """Schedule follow-up emails during onboarding"""
        # Day 1: Welcome (already sent)
        # Day 2: Check-in if not completed step 2
        # Day 4: Progress check
        # Day 7: Final nudge if not completed
        
        # In production, this would use Celery or similar
        logger.info(f"Scheduled onboarding follow-ups for customer: {customer_id}")
    
    async def get_stalled_customers(self, days: int = 3) -> List[Dict[str, Any]]:
        """
        Get customers who haven't progressed in onboarding
        
        Args:
            days: Number of days without progress
            
        Returns:
            List of stalled customers
        """
        try:
            cutoff = datetime.utcnow() - timedelta(days=days)
            
            # Get all customers who haven't completed onboarding
            customers = await self.supabase.select(
                "customers",
                {"onboarding_completed": False},
                limit=1000
            )
            
            stalled = []
            for customer in customers:
                created_at = datetime.fromisoformat(
                    customer['created_at'].replace('Z', '+00:00')
                )
                if created_at < cutoff:
                    progress = await self.get_progress(customer['id'])
                    stalled.append({
                        "customer": customer,
                        "progress": progress,
                        "days_since_signup": (datetime.utcnow() - created_at).days
                    })
            
            return stalled
            
        except Exception as e:
            logger.error(f"Failed to get stalled customers: {e}")
            return []
    
    async def send_progress_nudges(self):
        """Send nudges to customers who haven't progressed"""
        stalled = await self.get_stalled_customers(days=3)
        
        for item in stalled:
            customer = item['customer']
            progress = item['progress']
            
            if progress.get('next_step'):
                await self._send_step_reminder(
                    customer['id'],
                    progress['next_step']['number']
                )
        
        logger.info(f"Sent {len(stalled)} onboarding nudges")


# Global instance
onboarding_manager = OnboardingManager()
