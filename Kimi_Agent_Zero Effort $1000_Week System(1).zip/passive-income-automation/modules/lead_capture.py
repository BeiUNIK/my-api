"""
Lead Capture & Email Automation Module
Handles lead collection, verification, and automated email sequences
"""
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from pydantic import BaseModel, EmailStr
import uuid
import secrets
from loguru import logger

from database.supabase_client import get_supabase
from utils.error_handler import with_retry, fallback, EmailError
from utils.alerts import alert_manager
from config.settings import settings


class LeadCaptureRequest(BaseModel):
    """Lead capture request model"""
    email: EmailStr
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    source: Optional[str] = "website"
    landing_page: Optional[str] = None
    utm_source: Optional[str] = None
    utm_medium: Optional[str] = None
    utm_campaign: Optional[str] = None
    tags: Optional[List[str]] = []
    custom_fields: Optional[Dict[str, Any]] = {}


class LeadResponse(BaseModel):
    """Lead response model"""
    id: str
    email: str
    status: str
    verification_token: Optional[str] = None
    message: str


class LeadCaptureManager:
    """Manager for lead capture operations"""
    
    def __init__(self):
        self.supabase = get_supabase()
        self.welcome_sequence = WelcomeEmailSequence()
    
    async def capture_lead(self, lead_data: LeadCaptureRequest) -> LeadResponse:
        """
        Capture a new lead and trigger welcome sequence
        
        Args:
            lead_data: Lead information
            
        Returns:
            LeadResponse with lead details
        """
        try:
            # Check if lead already exists
            existing = await self._get_lead_by_email(lead_data.email)
            
            if existing:
                logger.info(f"Lead already exists: {lead_data.email}")
                return LeadResponse(
                    id=existing['id'],
                    email=existing['email'],
                    status=existing['status'],
                    message="Lead already subscribed"
                )
            
            # Generate verification token
            verification_token = secrets.token_urlsafe(32)
            
            # Prepare lead data
            lead_record = {
                "email": lead_data.email,
                "first_name": lead_data.first_name,
                "last_name": lead_data.last_name,
                "source": lead_data.source,
                "landing_page": lead_data.landing_page,
                "utm_source": lead_data.utm_source,
                "utm_medium": lead_data.utm_medium,
                "utm_campaign": lead_data.utm_campaign,
                "tags": lead_data.tags or [],
                "custom_fields": lead_data.custom_fields or {},
                "status": "pending_verification",
                "verification_token": verification_token,
                "subscribed_at": datetime.utcnow().isoformat()
            }
            
            # Insert into database
            result = await self.supabase.insert("leads", lead_record)
            lead_id = result.get('id')
            
            logger.info(f"New lead captured: {lead_data.email} (ID: {lead_id})")
            
            # Trigger welcome email sequence
            await self.welcome_sequence.send_welcome_email(
                lead_id=lead_id,
                email=lead_data.email,
                first_name=lead_data.first_name,
                verification_token=verification_token
            )
            
            # Schedule nurture sequence
            await self.welcome_sequence.schedule_nurture_sequence(
                lead_id=lead_id,
                email=lead_data.email,
                first_name=lead_data.first_name
            )
            
            return LeadResponse(
                id=lead_id,
                email=lead_data.email,
                status="pending_verification",
                verification_token=verification_token,
                message="Lead captured successfully. Please check your email to verify."
            )
            
        except Exception as e:
            logger.error(f"Failed to capture lead: {e}")
            await alert_manager.automation_error("lead_capture", str(e))
            raise
    
    async def verify_email(self, token: str) -> bool:
        """
        Verify lead email address
        
        Args:
            token: Verification token
            
        Returns:
            True if verified successfully
        """
        try:
            # Find lead by token
            leads = await self.supabase.select("leads", {"verification_token": token})
            
            if not leads:
                logger.warning(f"Invalid verification token: {token}")
                return False
            
            lead = leads[0]
            
            # Update lead status
            await self.supabase.update(
                "leads",
                lead['id'],
                {
                    "status": "verified",
                    "email_verified": True,
                    "verification_token": None,
                    "updated_at": datetime.utcnow().isoformat()
                }
            )
            
            logger.info(f"Lead email verified: {lead['email']}")
            
            # Trigger post-verification sequence
            await self.welcome_sequence.send_verification_success(
                lead_id=lead['id'],
                email=lead['email'],
                first_name=lead.get('first_name')
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Email verification failed: {e}")
            raise
    
    @with_retry(max_attempts=3)
    async def _get_lead_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Get lead by email address"""
        leads = await self.supabase.select("leads", {"email": email}, limit=1)
        return leads[0] if leads else None
    
    async def get_lead_stats(self) -> Dict[str, Any]:
        """Get lead statistics"""
        try:
            # This would use a more sophisticated query in production
            all_leads = await self.supabase.select("leads", limit=1000)
            
            return {
                "total_leads": len(all_leads),
                "verified": len([l for l in all_leads if l.get('email_verified')]),
                "pending": len([l for l in all_leads if l.get('status') == 'pending_verification']),
                "by_source": self._group_by_source(all_leads)
            }
        except Exception as e:
            logger.error(f"Failed to get lead stats: {e}")
            return {}
    
    def _group_by_source(self, leads: List[Dict]) -> Dict[str, int]:
        """Group leads by source"""
        sources = {}
        for lead in leads:
            source = lead.get('source', 'unknown')
            sources[source] = sources.get(source, 0) + 1
        return sources


class WelcomeEmailSequence:
    """Automated welcome email sequence"""
    
    def __init__(self):
        self.supabase = get_supabase()
        self.email_sender = EmailSender()
    
    async def send_welcome_email(
        self,
        lead_id: str,
        email: str,
        first_name: Optional[str],
        verification_token: str
    ):
        """Send initial welcome email with verification link"""
        verification_url = f"https://yourdomain.com/verify?token={verification_token}"
        
        subject = f"Welcome! Please verify your email"
        
        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h1 style="color: #2c3e50;">Welcome{f', {first_name}' if first_name else ''}!</h1>
                
                <p>Thank you for subscribing. Please verify your email address to get started.</p>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{verification_url}" 
                       style="background: #3498db; color: white; padding: 15px 30px; 
                              text-decoration: none; border-radius: 5px; display: inline-block;">
                        Verify Email Address
                    </a>
                </div>
                
                <p style="font-size: 12px; color: #666;">
                    Or copy and paste this link: {verification_url}
                </p>
                
                <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
                
                <p style="font-size: 12px; color: #999;">
                    If you didn't sign up for this, you can safely ignore this email.
                </p>
            </div>
        </body>
        </html>
        """
        
        await self.email_sender.send_email(
            to_email=email,
            subject=subject,
            html_content=html_content,
            lead_id=lead_id,
            campaign_type="welcome"
        )
    
    async def send_verification_success(
        self,
        lead_id: str,
        email: str,
        first_name: Optional[str]
    ):
        """Send email after successful verification"""
        subject = "Your email is verified! Here's what's next..."
        
        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h1 style="color: #27ae60;">✓ Email Verified!</h1>
                
                <p>Hi{f' {first_name}' if first_name else ''},</p>
                
                <p>Your email has been successfully verified. Here's what you can expect:</p>
                
                <ul style="padding-left: 20px;">
                    <li>Exclusive content delivered to your inbox</li>
                    <li>Early access to new features</li>
                    <li>Special offers and discounts</li>
                </ul>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                    <h3 style="margin-top: 0;">Ready to get started?</h3>
                    <a href="https://yourdomain.com/dashboard" 
                       style="background: #27ae60; color: white; padding: 12px 24px; 
                              text-decoration: none; border-radius: 5px; display: inline-block;">
                        Access Your Dashboard
                    </a>
                </div>
                
                <p>Thanks for joining us!</p>
            </div>
        </body>
        </html>
        """
        
        await self.email_sender.send_email(
            to_email=email,
            subject=subject,
            html_content=html_content,
            lead_id=lead_id,
            campaign_type="verification_success"
        )
    
    async def schedule_nurture_sequence(
        self,
        lead_id: str,
        email: str,
        first_name: Optional[str]
    ):
        """Schedule nurture sequence emails"""
        # This would integrate with a task queue like Celery
        # For now, we'll log the scheduled emails
        
        sequence = [
            {"day": 1, "type": "value_email", "subject": "Your first tip is here..."},
            {"day": 3, "type": "case_study", "subject": "How John achieved 10x results"},
            {"day": 7, "type": "offer", "subject": "Special offer inside (48 hours only)"},
        ]
        
        for email_config in sequence:
            scheduled_time = datetime.utcnow() + timedelta(days=email_config['day'])
            logger.info(
                f"Scheduled {email_config['type']} email for {email} "
                f"at {scheduled_time.isoformat()}"
            )
            # In production: celery_app.send_task('send_nurture_email', args=[...], eta=scheduled_time)


class EmailSender:
    """Email sending utility with SendGrid"""
    
    def __init__(self):
        self.sendgrid_api_key = settings.SENDGRID_API_KEY
        self.from_email = settings.EMAIL_FROM
        self.from_name = settings.EMAIL_FROM_NAME
    
    @with_retry(max_attempts=5, min_wait=2, max_wait=60)
    async def send_email(
        self,
        to_email: str,
        subject: str,
        html_content: str,
        text_content: Optional[str] = None,
        lead_id: Optional[str] = None,
        customer_id: Optional[str] = None,
        campaign_type: str = "transactional"
    ):
        """Send email via SendGrid"""
        try:
            from sendgrid import SendGridAPIClient
            from sendgrid.helpers.mail import Mail
            
            # Create email record
            email_record = {
                "email": to_email,
                "subject": subject,
                "status": "sending",
                "lead_id": lead_id,
                "customer_id": customer_id,
                "created_at": datetime.utcnow().isoformat()
            }
            
            # Log to database
            send_record = await get_supabase().insert("email_sends", email_record)
            
            # Send via SendGrid
            message = Mail(
                from_email=(self.from_email, self.from_name),
                to_emails=to_email,
                subject=subject,
                html_content=html_content,
                plain_text_content=text_content
            )
            
            sg = SendGridAPIClient(self.sendgrid_api_key)
            response = sg.send(message)
            
            if response.status_code in [200, 201, 202]:
                # Update status
                await get_supabase().update(
                    "email_sends",
                    send_record['id'],
                    {
                        "status": "sent",
                        "sent_at": datetime.utcnow().isoformat()
                    }
                )
                logger.info(f"Email sent to {to_email}: {subject}")
            else:
                raise EmailError(f"SendGrid returned status {response.status_code}")
                
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {e}")
            raise EmailError(f"Email sending failed: {str(e)}")


# Global instance
lead_capture_manager = LeadCaptureManager()
