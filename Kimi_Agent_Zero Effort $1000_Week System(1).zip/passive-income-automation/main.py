"""
Passive Income Automation System - Main Application
FastAPI application with all automation endpoints
"""
from fastapi import FastAPI, Request, HTTPException, Header, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from loguru import logger
import sys
import sentry_sdk
from datetime import datetime

from config.settings import settings
from database.supabase_client import get_supabase

# Import modules
from modules.lead_capture import (
    lead_capture_manager, 
    LeadCaptureRequest, 
    LeadResponse,
    EmailSender
)
from modules.payment_processor import (
    payment_processor,
    PaymentIntent,
    SubscriptionCreate
)
from modules.content_generator import (
    content_generator,
    content_pipeline,
    ContentRequest,
    GeneratedContent
)
from modules.onboarding import (
    onboarding_manager,
    OnboardingProgress
)
from utils.alerts import alert_manager


# Configure logging
logger.remove()
logger.add(
    sys.stdout,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
    level="INFO"
)
logger.add(
    "logs/app.log",
    rotation="500 MB",
    retention="10 days",
    level="DEBUG"
)

# Initialize Sentry for error tracking
if settings.SENTRY_DSN:
    sentry_sdk.init(
        dsn=settings.SENTRY_DSN,
        traces_sample_rate=1.0,
        profiles_sample_rate=1.0,
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    logger.info(f"Starting {settings.APP_NAME} in {settings.APP_ENV} mode")
    
    # Test database connection
    try:
        supabase = get_supabase()
        logger.info("Database connection established")
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
    
    yield
    
    # Shutdown
    logger.info(f"Shutting down {settings.APP_NAME}")


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    description="Automated passive income system with lead capture, payments, content generation, and onboarding",
    version="1.0.0",
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None,
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================
# ERROR HANDLERS
# ============================================

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {exc}")
    
    # Send alert for critical errors
    await alert_manager.send_alert(
        title="Unhandled Exception",
        message=str(exc),
        severity="error",
        details={"path": request.url.path, "method": request.method}
    )
    
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "error_code": "INTERNAL_ERROR"}
    )


# ============================================
# HEALTH & STATUS ENDPOINTS
# ============================================

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": settings.APP_NAME,
        "version": "1.0.0",
        "environment": settings.APP_ENV,
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        supabase = get_supabase()
        
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected",
            "services": {
                "stripe": "configured" if settings.STRIPE_SECRET_KEY else "not_configured",
                "sendgrid": "configured" if settings.SENDGRID_API_KEY else "not_configured",
                "openai": "configured" if settings.OPENAI_API_KEY else "not_configured"
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail="Service unhealthy")


# ============================================
# LEAD CAPTURE ENDPOINTS
# ============================================

@app.post("/api/v1/leads/capture", response_model=LeadResponse)
async def capture_lead(lead_data: LeadCaptureRequest):
    """
    Capture a new lead and trigger welcome sequence
    
    - **email**: Required lead email address
    - **first_name**: Optional first name
    - **last_name**: Optional last name
    - **source**: Lead source (default: website)
    - **landing_page**: URL of capture page
    - **utm_***: UTM tracking parameters
    """
    return await lead_capture_manager.capture_lead(lead_data)


@app.get("/api/v1/leads/verify")
async def verify_email(token: str):
    """Verify lead email address"""
    success = await lead_capture_manager.verify_email(token)
    if success:
        return {"status": "success", "message": "Email verified successfully"}
    else:
        raise HTTPException(status_code=400, detail="Invalid or expired token")


@app.get("/api/v1/leads/stats")
async def get_lead_stats():
    """Get lead capture statistics"""
    return await lead_capture_manager.get_lead_stats()


# ============================================
# PAYMENT ENDPOINTS
# ============================================

@app.post("/api/v1/payments/checkout")
async def create_checkout_session(
    customer_email: str,
    success_url: str,
    cancel_url: str,
    price_id: str = None
):
    """
    Create Stripe Checkout Session
    
    - **customer_email**: Customer email address
    - **success_url**: Redirect URL after successful payment
    - **cancel_url**: Redirect URL after cancelled payment
    - **price_id**: Optional Stripe price ID
    """
    return await payment_processor.create_checkout_session(
        customer_email=customer_email,
        success_url=success_url,
        cancel_url=cancel_url,
        price_id=price_id
    )


@app.post("/api/v1/payments/portal")
async def create_customer_portal(
    customer_id: str,
    return_url: str
):
    """Create customer portal session for subscription management"""
    return await payment_processor.create_customer_portal_session(
        customer_id=customer_id,
        return_url=return_url
    )


@app.post("/api/v1/payments/webhook")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="Stripe-Signature")
):
    """
    Stripe webhook endpoint
    
    Configure this URL in your Stripe Dashboard webhook settings
    """
    if not stripe_signature:
        raise HTTPException(status_code=400, detail="Missing Stripe signature")
    
    return await payment_processor.handle_webhook(request, stripe_signature)


@app.get("/api/v1/payments/stats")
async def get_payment_stats():
    """Get revenue and payment statistics"""
    return await payment_processor.get_revenue_stats()


# ============================================
# CONTENT GENERATION ENDPOINTS
# ============================================

@app.post("/api/v1/content/generate", response_model=GeneratedContent)
async def generate_content(request: ContentRequest):
    """
    Generate content using AI
    
    - **topic**: Content topic/subject
    - **content_type**: Type of content (blog, email, social, product)
    - **tone**: Writing tone (professional, casual, persuasive)
    - **keywords**: SEO keywords to include
    - **word_count**: Target word count
    """
    return await content_generator.generate_content(request)


@app.post("/api/v1/content/schedule")
async def schedule_content(topics: list, content_type: str = "blog"):
    """Schedule content generation for multiple topics"""
    await content_generator.schedule_content_generation(topics, content_type)
    return {"status": "scheduled", "topics": len(topics)}


@app.post("/api/v1/content/{content_id}/publish")
async def publish_content(content_id: str):
    """Publish generated content"""
    success = await content_generator.publish_content(content_id)
    if success:
        return {"status": "published", "content_id": content_id}
    else:
        raise HTTPException(status_code=500, detail="Failed to publish content")


@app.get("/api/v1/content/stats")
async def get_content_stats():
    """Get content generation statistics"""
    return await content_generator.get_content_stats()


@app.get("/api/v1/content/ideas")
async def get_content_ideas(niche: str, count: int = 5):
    """Generate content ideas for a niche"""
    ideas = await content_generator.get_content_ideas(niche, count)
    return {"ideas": ideas}


# ============================================
# ONBOARDING ENDPOINTS
# ============================================

@app.post("/api/v1/onboarding/{customer_id}/start")
async def start_onboarding(customer_id: str):
    """Start onboarding for a new customer"""
    return await onboarding_manager.start_onboarding(customer_id)


@app.post("/api/v1/onboarding/{customer_id}/complete/{step_number}")
async def complete_onboarding_step(customer_id: str, step_number: int):
    """Mark an onboarding step as complete"""
    return await onboarding_manager.complete_step(customer_id, step_number)


@app.get("/api/v1/onboarding/{customer_id}/progress")
async def get_onboarding_progress(customer_id: str):
    """Get customer onboarding progress"""
    return await onboarding_manager.get_progress(customer_id)


@app.get("/api/v1/onboarding/stalled")
async def get_stalled_customers(days: int = 3):
    """Get customers who haven't progressed in onboarding"""
    return await onboarding_manager.get_stalled_customers(days)


# ============================================
# AUTOMATION ENDPOINTS
# ============================================

@app.post("/api/v1/automation/run-content-pipeline")
async def run_content_pipeline(background_tasks: BackgroundTasks):
    """Run the daily content generation pipeline"""
    background_tasks.add_task(content_pipeline.run_daily_pipeline)
    return {"status": "started", "message": "Content pipeline running in background"}


@app.post("/api/v1/automation/send-onboarding-nudges")
async def send_onboarding_nudges(background_tasks: BackgroundTasks):
    """Send nudges to customers who haven't progressed in onboarding"""
    background_tasks.add_task(onboarding_manager.send_progress_nudges)
    return {"status": "started", "message": "Onboarding nudges running in background"}


# ============================================
# ADMIN & MONITORING ENDPOINTS
# ============================================

@app.get("/api/v1/admin/dashboard")
async def admin_dashboard():
    """Admin dashboard with key metrics"""
    try:
        lead_stats = await lead_capture_manager.get_lead_stats()
        payment_stats = await payment_processor.get_revenue_stats()
        content_stats = await content_generator.get_content_stats()
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "leads": lead_stats,
            "revenue": payment_stats,
            "content": content_stats,
            "summary": {
                "total_leads": lead_stats.get('total_leads', 0),
                "total_revenue": payment_stats.get('total_revenue', 0),
                "active_customers": payment_stats.get('total_payments', 0),
                "published_content": content_stats.get('published', 0)
            }
        }
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        raise HTTPException(status_code=500, detail="Failed to load dashboard")


@app.post("/api/v1/admin/send-test-alert")
async def send_test_alert(message: str = "Test alert"):
    """Send a test alert"""
    await alert_manager.send_alert(
        title="Test Alert",
        message=message,
        severity="info"
    )
    return {"status": "sent"}


# ============================================
# MAIN ENTRY POINT
# ============================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level="info"
    )
