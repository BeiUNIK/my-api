# COMPLETE SYSTEM SETUP INSTRUCTIONS
## $1000/Week Passive Income Automation System

---

## 🎯 WHAT YOU'RE BUILDING

A fully automated business that generates $1,000+/week through:
- AI-powered SaaS subscriptions ($27-97/mo)
- Digital product sales ($47-97 one-time)
- Automated upsells and annual plans

**Your involvement after setup: 0 hours/week**

---

## 📋 PRE-SETUP CHECKLIST

Before starting, make sure you have:
- [ ] Computer with internet access
- [ ] Email address (for account creation)
- [ ] Credit card (for API keys and domain - $400-600 startup budget)
- [ ] 2-3 hours for initial setup

---

## 🚀 STEP-BY-STEP SETUP

### STEP 1: Create Accounts (30 minutes)

Create accounts on these platforms in order:

| Platform | Purpose | Cost | Link |
|----------|---------|------|------|
| **Supabase** | Database | FREE | supabase.com |
| **Stripe** | Payments | FREE (2.9% + $0.30/transaction) | stripe.com |
| **SendGrid** | Email | FREE (100 emails/day) | sendgrid.com |
| **Make.com** | Automation | $31/mo | make.com |
| **Claude (Anthropic)** | AI | Pay per use (~$150/mo) | console.anthropic.com |
| **OpenAI** | AI | Pay per use (~$100/mo) | platform.openai.com |
| **Webflow** | Website | $23/mo | webflow.com |

**Important:**
- Use the same email for all accounts
- Enable 2FA on all accounts
- Save API keys in a secure location (you'll need them in Step 2)

---

### STEP 2: Configure Environment (15 minutes)

1. Open `configs/.env.template`
2. Fill in your actual API keys:
   - `ANTHROPIC_API_KEY` (from Claude console)
   - `OPENAI_API_KEY` (from OpenAI platform)
   - `SUPABASE_URL` and `SUPABASE_KEY` (from Supabase settings)
   - `STRIPE_SECRET_KEY` (from Stripe dashboard)
   - `SENDGRID_API_KEY` (from SendGrid settings)
3. Save as `.env` (remove "template" from filename)

---

### STEP 3: Set Up Stripe Products (20 minutes)

1. Log in to Stripe Dashboard
2. Go to "Products" → "Add Product"
3. Create 3 products:

**Product 1: Starter Plan**
- Name: "AI Content Studio - Starter"
- Price: $27.00 (recurring, monthly)
- Description: "Perfect for solo creators getting started"

**Product 2: Professional Plan**
- Name: "AI Content Studio - Professional"
- Price: $97.00 (recurring, monthly)
- Description: "For serious content creators and teams"

**Product 3: Annual Plan**
- Name: "AI Content Studio - Annual"
- Price: $970.00 (recurring, yearly)
- Description: "Save 2 months with annual billing"

4. Copy the Price IDs (they look like `price_1234567890`)
5. Paste them into your `.env` file:
   - `STRIPE_PRICE_STARTER`
   - `STRIPE_PRICE_PRO`
   - `STRIPE_PRICE_ANNUAL`

---

### STEP 4: Set Up Stripe Webhook (10 minutes)

1. In Stripe Dashboard, go to "Developers" → "Webhooks"
2. Click "Add endpoint"
3. Enter your webhook URL (you'll get this after deployment)
   - For now, use: `https://your-site.com/api/v1/payments/webhook`
4. Select events to listen for:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `customer.subscription.created`
   - `customer.subscription.deleted`
5. Copy the "Signing secret"
6. Paste into `.env` as `STRIPE_WEBHOOK_SECRET`

---

### STEP 5: Deploy the API (10 minutes)

#### Option A: Deploy to Vercel (Recommended - FREE)

```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Log in to Vercel
vercel login

# 3. Navigate to deployment folder
cd deployment

# 4. Run deployment script
chmod +x deploy-full-system.sh
./deploy-full-system.sh

# 5. Choose "Vercel" when prompted
```

#### Option B: Deploy to Railway ($5/month)

```bash
# 1. Install Railway CLI
npm install -g @railway/cli

# 2. Log in to Railway
railway login

# 3. Navigate to deployment folder
cd deployment

# 4. Run deployment script
./deploy-full-system.sh

# 5. Choose "Railway" when prompted
```

**After deployment:**
- Copy your API URL (e.g., `https://your-app.vercel.app`)
- Update `SITE_URL` in your `.env` file
- Update Stripe webhook URL with actual domain

---

### STEP 6: Set Up Make.com Workflows (30 minutes)

1. Log in to Make.com
2. Click "Create a new scenario"
3. For each workflow in `make-workflows/` folder:

**Workflow 1: Lead Capture**
- Import: `01-lead-capture-workflow.json`
- Configure webhook URL from your deployment
- Connect: Supabase, SendGrid, HubSpot (optional), Slack
- Activate scenario

**Workflow 2: Payment Processing**
- Import: `02-payment-processing-workflow.json`
- Configure Stripe webhook
- Connect: Stripe, Supabase, MemberStack, SendGrid, Slack
- Activate scenario

**Workflow 3: Content Generation**
- Import: `03-content-generation-workflow.json`
- Configure schedule (daily at 9 AM)
- Connect: Claude API, OpenAI, Webflow, Buffer
- Activate scenario

**Workflow 4: Customer Onboarding**
- Import: `04-customer-onboarding-workflow.json`
- Configure email delays
- Connect: SendGrid, Supabase
- Activate scenario

**Workflow 5: Support Automation**
- Import: `05-support-automation-workflow.json`
- Configure Intercom webhook (or email)
- Connect: Claude API, Supabase, Slack
- Activate scenario

---

### STEP 7: Set Up SendGrid Email Templates (30 minutes)

1. Log in to SendGrid
2. Go to "Email API" → "Dynamic Templates"
3. Create templates for:

**Template 1: Welcome Email**
- Template ID: `d-welcome`
- Subject: "Welcome to AI Content Studio!"
- Content: Welcome message + login instructions

**Template 2: Payment Confirmation**
- Template ID: `d-payment-confirmation`
- Subject: "Your payment was successful!"
- Content: Payment details + next steps

**Template 3: Onboarding Email 1 (Day 0)**
- Template ID: `d-onboarding-welcome`
- Subject: "Let's get you started..."
- Content: Quick start guide

**Template 4: Onboarding Email 2 (Day 3)**
- Template ID: `d-onboarding-quick-win`
- Subject: "Your first piece of content..."
- Content: Tutorial for quick win

**Template 5: Onboarding Email 3 (Day 7)**
- Template ID: `d-onboarding-advanced`
- Subject: "Advanced features you'll love..."
- Content: Advanced tutorial

**Template 6: Upgrade Offer**
- Template ID: `d-upgrade-offer`
- Subject: "Ready to unlock more power?"
- Content: Upgrade benefits + discount code

4. Copy template IDs to Make.com workflows

---

### STEP 8: Set Up Website (30 minutes)

#### Option A: Webflow (Recommended)

1. Log in to Webflow
2. Create new site from template or blank
3. Import the template from `webflow-template/`
4. Customize:
   - Update logo and brand name
   - Update colors to match your brand
   - Add your actual testimonials
   - Update pricing to match Stripe
   - Connect checkout buttons to Stripe
5. Publish site
6. Copy domain and update `.env` and Make.com workflows

#### Option B: Use Template HTML

1. Open `webflow-template/index.html`
2. Edit in any text editor
3. Customize content
4. Deploy to Netlify, Vercel, or your host
5. Connect domain

---

### STEP 9: Configure AI Prompts (15 minutes)

1. Open `ai-prompts/` folder
2. Review each prompt file:
   - `content-agent-prompts.md`
   - `sales-agent-prompts.md`
   - `support-agent-prompts.md`
3. Customize for your business:
   - Update `{{NICHE}}` with your actual niche
   - Update `{{BUSINESS_NAME}}` with your brand
   - Adjust tone and style to match your brand
4. Copy prompts into Make.com AI modules

---

### STEP 10: Test Everything (30 minutes)

#### Test Lead Capture:
1. Go to your website
2. Fill out lead capture form
3. Check:
   - [ ] Lead appears in Supabase
   - [ ] Welcome email sent
   - [ ] Slack notification received

#### Test Payment Flow:
1. Go to pricing page
2. Click "Start Free Trial"
3. Complete Stripe checkout (use test card: 4242 4242 4242 4242)
4. Check:
   - [ ] Payment processed in Stripe
   - [ ] Customer added to Supabase
   - [ ] MemberStack access granted
   - [ ] Confirmation email sent
   - [ ] Onboarding sequence started

#### Test Content Generation:
1. Go to Make.com
2. Manually run "Content Generation" scenario
3. Check:
   - [ ] AI generates content
   - [ ] Content published to blog
   - [ ] Social posts scheduled

#### Test Support:
1. Send test support message
2. Check:
   - [ ] AI classifies intent
   - [ ] Response generated
   - [ ] Response sent to customer

---

## 🎉 LAUNCH CHECKLIST

Before going live, verify:

- [ ] All API keys configured in `.env`
- [ ] Stripe products created with correct pricing
- [ ] Stripe webhook configured and tested
- [ ] Make.com workflows imported and activated
- [ ] SendGrid email templates created
- [ ] Website deployed and live
- [ ] Payment flow tested end-to-end
- [ ] Lead capture tested
- [ ] Email sequences tested
- [ ] Content generation tested
- [ ] Support automation tested
- [ ] Slack notifications working
- [ ] Monitoring dashboard accessible

---

## 📊 POST-LAUNCH MONITORING

### Daily (Automated):
- Revenue tracking
- New signups
- System health checks
- Content publishing

### Weekly (5 minutes):
- Review analytics dashboard
- Check AI content quality
- Monitor API costs
- Respond to any alerts

### Monthly (30 minutes):
- Review conversion rates
- Optimize pricing if needed
- Update AI prompts based on performance
- Plan new content/topics

---

## 🚨 TROUBLESHOOTING

### Issue: API not responding
**Solution:**
- Check Vercel/Railway logs
- Verify environment variables
- Check API health: `curl https://your-api.com/health`

### Issue: Payments not processing
**Solution:**
- Verify Stripe webhook URL
- Check Stripe webhook secret
- Test with Stripe test mode

### Issue: Emails not sending
**Solution:**
- Verify SendGrid API key
- Check email template IDs
- Review SendGrid activity log

### Issue: Make.com workflows failing
**Solution:**
- Check connection credentials
- Review execution logs
- Verify API rate limits

### Issue: AI content quality poor
**Solution:**
- Refine prompts in AI modules
- Add more examples to prompts
- Adjust temperature settings

---

## 💰 EXPECTED TIMELINE TO $1000/WEEK

| Week | Actions | Expected Revenue |
|------|---------|------------------|
| 1 | Setup system, soft launch | $0-100 |
| 2 | Content marketing, SEO | $100-300 |
| 3 | Social media, partnerships | $300-600 |
| 4 | Optimize conversions | $600-900 |
| 5-6 | Scale winners | $900-1,200 |
| 7+ | Maintain & optimize | $1,000+ |

---

## 📞 SUPPORT RESOURCES

- **Documentation:** `MASTER_IMPLEMENTATION_PLAN.md`
- **Quick Start:** `QUICK_START_GUIDE.md`
- **AI Prompts:** `ai-prompts/` folder
- **Code:** `passive-income-automation/` folder

---

## 🎯 SUCCESS METRICS

Track these weekly:
- New leads: Target 50+/week
- Conversion rate: Target 5-10%
- Churn rate: Keep under 10%/month
- Customer LTV: Target $500+
- API costs: Keep under 20% of revenue

---

**You're now ready to build your $1000/week passive income system!**

**Remember:** The system is designed to run itself. After setup, your only job is to monitor alerts and optimize periodically.

**Good luck! 🚀**
